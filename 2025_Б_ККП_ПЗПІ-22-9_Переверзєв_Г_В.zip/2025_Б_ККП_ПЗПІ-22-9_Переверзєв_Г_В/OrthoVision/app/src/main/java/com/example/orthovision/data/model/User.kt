package com.example.orthovision.data.model

data class User(
    val avatar: String?,
    val email: String,
    val id: Int,
    val name: String
)