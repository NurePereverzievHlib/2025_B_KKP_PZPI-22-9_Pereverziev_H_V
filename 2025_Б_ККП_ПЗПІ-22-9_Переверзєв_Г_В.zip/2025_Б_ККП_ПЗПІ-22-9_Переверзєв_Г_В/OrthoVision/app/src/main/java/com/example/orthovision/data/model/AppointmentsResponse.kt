package com.example.orthovision.data.model

data class AppointmentsResponse(
    val data: List<AppointmentTime>?,
    val message: String
)