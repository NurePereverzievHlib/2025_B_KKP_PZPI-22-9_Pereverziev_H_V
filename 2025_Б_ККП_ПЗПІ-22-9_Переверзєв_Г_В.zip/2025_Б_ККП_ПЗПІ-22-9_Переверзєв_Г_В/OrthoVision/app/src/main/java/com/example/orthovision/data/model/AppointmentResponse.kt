package com.example.orthovision.data.model

data class AppointmentResponse(
    val data: List<Appointment>,
    val message: String
)

