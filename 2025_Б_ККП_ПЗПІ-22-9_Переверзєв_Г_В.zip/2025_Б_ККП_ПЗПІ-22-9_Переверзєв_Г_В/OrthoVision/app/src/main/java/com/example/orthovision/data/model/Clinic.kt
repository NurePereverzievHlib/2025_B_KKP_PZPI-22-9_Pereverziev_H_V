package com.example.orthovision.data.model

data class Clinic(
    val id : String,
    val name: String,
    val address: String,
    val phone: String,
    val location: String
)
