package com.example.orthovision.data.model

data class DoctorsResponse(
    val doctors: List<Doctor>
)
