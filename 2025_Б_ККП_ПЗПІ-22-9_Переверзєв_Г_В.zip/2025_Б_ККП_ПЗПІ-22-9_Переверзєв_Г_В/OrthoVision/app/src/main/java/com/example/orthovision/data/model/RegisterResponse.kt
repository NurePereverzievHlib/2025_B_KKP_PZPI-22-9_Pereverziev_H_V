package com.example.orthovision.data.model

data class RegisterResponse(
    val message: String,
    val user: User?
)

