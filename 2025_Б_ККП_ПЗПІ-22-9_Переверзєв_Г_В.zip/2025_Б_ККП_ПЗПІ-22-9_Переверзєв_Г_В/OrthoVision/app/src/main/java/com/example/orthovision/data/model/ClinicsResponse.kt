package com.example.orthovision.data.model

data class ClinicsResponse(
    val clinics: List<ClinicResponse>,
    val message: String
)