export default function AdminPage() {
  return <div className="p-4">Admin Dashboard</div>;
}
