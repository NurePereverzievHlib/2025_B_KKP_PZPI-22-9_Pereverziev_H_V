export default function DoctorPage() {
  return <div className="p-4">Doctor Dashboard</div>;
}
